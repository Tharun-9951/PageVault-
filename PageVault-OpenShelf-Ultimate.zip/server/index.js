import express from 'express';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import jwt from 'jsonwebtoken';
import { z } from 'zod';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_FILE = process.env.DB_PATH || path.join(__dirname, 'data', 'pagevault.sqlite');
const LEGACY_FILE = path.join(__dirname, 'data', 'db.json');
// Never ship a known signing key. Production must provide a secret; local development gets a fresh process secret.
if (process.env.NODE_ENV === 'production' && !process.env.JWT_SECRET) {
  throw new Error('JWT_SECRET is required in production. Set a long, random secret before starting PageVault.');
}
const JWT_SECRET = process.env.JWT_SECRET || randomBytes(48).toString('base64url');
const TOKEN_TTL = '12h';
const db = new DatabaseSync(DB_FILE);
db.exec(`
 PRAGMA foreign_keys = ON;
 PRAGMA journal_mode = WAL;
 CREATE TABLE IF NOT EXISTS users (
   id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
   password_hash TEXT NOT NULL, created_at TEXT NOT NULL
 );
 CREATE TABLE IF NOT EXISTS books (
   id TEXT PRIMARY KEY, title TEXT NOT NULL, author TEXT NOT NULL, edition TEXT NOT NULL,
   course_code TEXT NOT NULL, department TEXT NOT NULL, condition TEXT NOT NULL,
   owner TEXT NOT NULL, owner_email TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Available',
   created_at TEXT NOT NULL, cover TEXT DEFAULT ''
 );
 CREATE TABLE IF NOT EXISTS requests (
   id TEXT PRIMARY KEY, book_id TEXT NOT NULL REFERENCES books(id) ON DELETE CASCADE,
   book_title TEXT NOT NULL, borrower TEXT NOT NULL, lender TEXT NOT NULL,
   borrower_email TEXT NOT NULL DEFAULT '', lender_email TEXT NOT NULL DEFAULT '', status TEXT NOT NULL, created_at TEXT NOT NULL, due_date TEXT,
   approved_at TEXT, rejected_at TEXT, returned_at TEXT
 );
 CREATE TABLE IF NOT EXISTS notifications (
   id TEXT PRIMARY KEY, user TEXT NOT NULL, user_email TEXT NOT NULL DEFAULT '', message TEXT NOT NULL,
   type TEXT NOT NULL DEFAULT 'info', created_at TEXT NOT NULL, read INTEGER NOT NULL DEFAULT 0
 );
 CREATE INDEX IF NOT EXISTS idx_books_status ON books(status);
 CREATE INDEX IF NOT EXISTS idx_books_department ON books(department);
 CREATE INDEX IF NOT EXISTS idx_requests_book_status ON requests(book_id,status);
 CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user,created_at);
`);

const now = () => new Date().toISOString();
const id = () => randomUUID();
const hashPassword = password => {
  const salt = randomUUID();
  return `${salt}:${scryptSync(password, salt, 64).toString('hex')}`;
};
const verifyPassword = (password, stored) => {
  const [salt, key] = String(stored).split(':');
  if (!salt || !key) return false;
  const expected = Buffer.from(key, 'hex');
  const actual = scryptSync(password, salt, 64);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
};
const registerSchema = z.object({
  name: z.string().trim().min(2).max(60),
  email: z.string().trim().email().max(160).transform(v => v.toLowerCase()),
  password: z.string().min(8).max(128)
});
const bookSchema = z.object({
  title: z.string().trim().min(1).max(160),
  author: z.string().trim().min(1).max(120),
  edition: z.string().trim().max(60).optional().default('Not specified'),
  courseCode: z.string().trim().min(1).max(30),
  department: z.string().trim().min(1).max(80),
  condition: z.enum(['Like New','Good','Fair'])
});

function migrateLegacyData() {
  const count = db.prepare('SELECT COUNT(*) AS n FROM books').get().n;
  if (count || !fs.existsSync(LEGACY_FILE)) return;
  try {
    const legacy = JSON.parse(fs.readFileSync(LEGACY_FILE, 'utf8'));
    const insertBook = db.prepare(`INSERT OR IGNORE INTO books
      (id,title,author,edition,course_code,department,condition,owner,owner_email,status,created_at,cover)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);
    for (const b of legacy.books || []) insertBook.run(b.id,b.title,b.author,b.edition||'Not specified',b.courseCode,b.department,b.condition,b.owner,b.ownerEmail||'',b.status||'Available',b.createdAt||now(),b.cover||'');
    const insertRequest = db.prepare(`INSERT OR IGNORE INTO requests
      (id,book_id,book_title,borrower,lender,borrower_email,lender_email,status,created_at,due_date,approved_at,rejected_at,returned_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    for (const r of legacy.requests || []) {
      const borrowerBook = legacy.books?.find(b=>b.owner===r.borrower);
      const lenderBook = legacy.books?.find(b=>b.owner===r.lender);
      insertRequest.run(r.id,r.bookId,r.bookTitle,r.borrower,r.lender,'',lenderBook?.ownerEmail||'',r.status,r.createdAt,r.dueDate,r.approvedAt||null,r.rejectedAt||null,r.returnedAt||null);
    }
    const insertNote = db.prepare(`INSERT OR IGNORE INTO notifications (id,user,user_email,message,type,created_at,read) VALUES (?,?,?,?,?,?,?)`);
    for (const n of legacy.notifications || []) insertNote.run(n.id,n.user,'',n.message,n.type||'info',n.createdAt,n.read?1:0);
  } catch (error) {
    console.error('Legacy data migration skipped:', error.message);
  }
}
migrateLegacyData();

// Structured JSON logs make failures searchable by level, event and timestamp.
const log = (level, event, fields = {}) => process.stdout.write(JSON.stringify({ timestamp: now(), level, event, ...fields }) + '\n');

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN || true }));
app.use(express.json({ limit: '100kb' }));
app.disable('x-powered-by');

function issueToken(user) {
  return jwt.sign({ sub: user.id, name: user.name, email: user.email }, JWT_SECRET, { expiresIn: TOKEN_TTL });
}
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'Please sign in to continue.' });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { return res.status(401).json({ error: 'Your session expired. Please sign in again.' }); }
}
function notify(user, message, type='info', email='') {
  db.prepare('INSERT INTO notifications (id,user,user_email,message,type,created_at,read) VALUES (?,?,?,?,?,?,0)')
    .run(id(),user,email,message,type,now());
}
function bookFromRow(b) {
  return { id:b.id,title:b.title,author:b.author,edition:b.edition,courseCode:b.course_code,
    department:b.department,condition:b.condition,owner:b.owner,ownerEmail:b.owner_email,
    status:b.status,createdAt:b.created_at,cover:b.cover||'' };
}
function requestFromRow(r) {
  return { id:r.id,bookId:r.book_id,bookTitle:r.book_title,borrower:r.borrower,lender:r.lender,
    status:r.status,createdAt:r.created_at,dueDate:r.due_date,approvedAt:r.approved_at,
    rejectedAt:r.rejected_at,returnedAt:r.returned_at };
}

app.get('/api/health', (_req,res)=>res.json({ok:true,app:'PageVault API',storage:'SQLite'}));
app.post('/api/auth/register', (req,res)=>{
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:parsed.error.issues[0]?.message || 'Invalid account details.'});
  const {name,email,password}=parsed.data;
  if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) return res.status(409).json({error:'An account with this email already exists.'});
  const user={id:id(),name,email};
  db.prepare('INSERT INTO users (id,name,email,password_hash,created_at) VALUES (?,?,?,?,?)')
    .run(user.id,name,email,hashPassword(password),now());
  res.status(201).json({token:issueToken(user),user});
});
app.post('/api/auth/login', (req,res)=>{
  const email=String(req.body.email||'').trim().toLowerCase(), password=String(req.body.password||'');
  const user=db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user || !verifyPassword(password,user.password_hash)) return res.status(401).json({error:'Email or password is incorrect.'});
  res.json({token:issueToken(user),user:{id:user.id,name:user.name,email:user.email}});
});
app.get('/api/auth/me',auth,(req,res)=>res.json({id:req.user.sub,name:req.user.name,email:req.user.email}));

app.use('/api', (req,res,next)=>{
  if (req.path.startsWith('/auth/')) return next();
  return auth(req,res,next);
});
app.get('/api/books',(req,res)=>{
  const q=String(req.query.q||'').trim().slice(0,160), status=String(req.query.status||'All'), dept=String(req.query.department||'All');
  const pageMode = req.query.page !== undefined || req.query.limit !== undefined;
  const page = Math.max(1, Number.parseInt(req.query.page || '1',10) || 1);
  const limit = Math.min(50, Math.max(1, Number.parseInt(req.query.limit || '12',10) || 12));
  const where = []; const params = [];
  if(q){where.push('(LOWER(title) LIKE ? OR LOWER(author) LIKE ? OR LOWER(course_code) LIKE ? OR LOWER(department) LIKE ? OR LOWER(owner) LIKE ?)'); const term=`%${q.toLowerCase()}%`;params.push(term,term,term,term,term);}
  if(status!=='All'){where.push('status=?');params.push(status);}
  if(dept!=='All'){where.push('department=?');params.push(dept);}
  const clause=where.length?`WHERE ${where.join(' AND ')}`:'';
  const total=db.prepare(`SELECT COUNT(*) AS total FROM books ${clause}`).get(...params).total;
  const rows = pageMode ? db.prepare(`SELECT * FROM books ${clause} ORDER BY created_at DESC LIMIT ? OFFSET ?`).all(...params,limit,(page-1)*limit) : db.prepare(`SELECT * FROM books ${clause} ORDER BY created_at DESC`).all(...params);
  const items=rows.map(bookFromRow);
  res.json(pageMode?{items,total,page,limit,pages:Math.max(1,Math.ceil(total/limit))}:items);
});
app.post('/api/books',(req,res)=>{
  const parsed=bookSchema.safeParse(req.body);
  if(!parsed.success) return res.status(400).json({error:parsed.error.issues[0]?.message||'Invalid book details.'});
  const b=parsed.data, user=req.user;
  const book={id:id(),...b,edition:b.edition||'Not specified',courseCode:b.courseCode.toUpperCase(),owner:user.name,ownerEmail:user.email,status:'Available',createdAt:now(),cover:''};
  db.prepare(`INSERT INTO books (id,title,author,edition,course_code,department,condition,owner,owner_email,status,created_at,cover)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(book.id,book.title,book.author,book.edition,book.courseCode,book.department,book.condition,book.owner,book.ownerEmail,book.status,book.createdAt,'');
  res.status(201).json(book);
});
app.delete('/api/books/:id',(req,res)=>{
  const book=db.prepare('SELECT * FROM books WHERE id=?').get(req.params.id);
  if(!book) return res.status(404).json({error:'Book not found.'});
  if(book.owner_email!==req.user.email) return res.status(403).json({error:'Only the listing owner can remove this book.'});
  if(db.prepare("SELECT id FROM requests WHERE book_id=? AND status='Approved'").get(book.id)) return res.status(409).json({error:'Return the book before removing this listing.'});
  db.prepare('DELETE FROM books WHERE id=?').run(book.id); res.json({ok:true});
});
app.get('/api/requests',(req,res)=>{
  const u=req.user.email;
  const rows=db.prepare('SELECT * FROM requests WHERE borrower_email=? OR lender_email=? ORDER BY created_at DESC').all(u,u);
  res.json(rows.map(r=>({...requestFromRow(r),book:db.prepare('SELECT * FROM books WHERE id=?').get(r.book_id)})));
});
app.post('/api/requests',(req,res)=>{
  const book=db.prepare('SELECT * FROM books WHERE id=?').get(String(req.body.bookId||''));
  const borrower=req.user.name;
  if(!book) return res.status(404).json({error:'Book not found.'});
  if(book.owner_email===req.user.email) return res.status(400).json({error:'You cannot request your own book.'});
  if(book.status!=='Available') return res.status(409).json({error:'This book is no longer available.'});
  const request={id:id(),bookId:book.id,bookTitle:book.title,borrower,lender:book.owner,status:'Pending',createdAt:now(),dueDate:null};
  const tx=db.prepare('INSERT INTO requests (id,book_id,book_title,borrower,lender,borrower_email,lender_email,status,created_at,due_date) VALUES (?,?,?,?,?,?,?,?,?,?)');
  db.exec('BEGIN IMMEDIATE');
  try {
    const current=db.prepare('SELECT status FROM books WHERE id=?').get(book.id);
    const active=db.prepare("SELECT id FROM requests WHERE book_id=? AND status IN ('Pending','Approved')").get(book.id);
    if(current.status!=='Available'||active) throw new Error('This book is no longer available.');
    tx.run(request.id,request.bookId,request.bookTitle,request.borrower,request.lender,req.user.email,book.owner_email,request.status,request.createdAt,null);
    db.prepare("UPDATE books SET status='Reserved' WHERE id=?").run(book.id);
    notify(book.owner,`${borrower} requested “${book.title}”.`,'request',book.owner_email);
    db.exec('COMMIT');
  } catch(e) { db.exec('ROLLBACK'); return res.status(409).json({error:e.message}); }
  res.status(201).json(request);
});
app.patch('/api/requests/:id',(req,res)=>{
  const r=db.prepare('SELECT * FROM requests WHERE id=?').get(req.params.id);
  if(!r) return res.status(404).json({error:'Request not found.'});
  const book=db.prepare('SELECT * FROM books WHERE id=?').get(r.book_id);
  const action=req.body.action, actor=req.user.name;
  db.exec('BEGIN IMMEDIATE');
  try {
    if(action==='approve'||action==='reject'){
      if(r.lender_email!==req.user.email) throw Object.assign(new Error('Only the lender can respond to this request.'),{status:403});
      if(r.status!=='Pending') throw Object.assign(new Error('This request has already been handled.'),{status:409});
      if(action==='approve'){
        const due=new Date(Date.now()+14*86400000).toISOString();
        db.prepare("UPDATE requests SET status='Approved',approved_at=?,due_date=? WHERE id=?").run(now(),due,r.id);
        db.prepare("UPDATE books SET status='Borrowed' WHERE id=?").run(r.book_id);
        notify(r.borrower,`Your request for “${book.title}” was approved. Return it by ${new Date(due).toLocaleDateString()}.`,'success',r.borrower_email);
      } else {
        db.prepare("UPDATE requests SET status='Rejected',rejected_at=? WHERE id=?").run(now(),r.id);
        db.prepare("UPDATE books SET status='Available' WHERE id=?").run(r.book_id);
        notify(r.borrower,`Your request for “${book.title}” was declined.`,'info',r.borrower_email);
      }
    } else if(action==='returned'){
      if(r.borrower_email!==req.user.email&&r.lender_email!==req.user.email) throw Object.assign(new Error('Only the borrower or lender can mark this returned.'),{status:403});
      if(!['Approved','Overdue'].includes(r.status)) throw Object.assign(new Error('Only an active exchange can be returned.'),{status:409});
      db.prepare("UPDATE requests SET status='Returned',returned_at=? WHERE id=?").run(now(),r.id);
      db.prepare("UPDATE books SET status='Available' WHERE id=?").run(r.book_id);
      notify(r.lender,`“${book.title}” has been marked as returned.`,'success',r.lender_email);
    } else throw Object.assign(new Error('Unknown action.'),{status:400});
    db.exec('COMMIT');
  } catch(e) { db.exec('ROLLBACK'); return res.status(e.status||400).json({error:e.message}); }
  res.json(requestFromRow(db.prepare('SELECT * FROM requests WHERE id=?').get(r.id)));
});
app.get('/api/notifications',(req,res)=>res.json(db.prepare('SELECT id,user,message,type,created_at AS createdAt,read FROM notifications WHERE user_email=? ORDER BY created_at DESC LIMIT 30').all(req.user.email).map(n=>({...n,read:!!n.read}))));
app.patch('/api/notifications/read',(req,res)=>{db.prepare('UPDATE notifications SET read=1 WHERE user_email=?').run(req.user.email);res.json({ok:true});});
app.get('/api/stats',(req,res)=>{
 const u=req.user.email;
 res.json({listed:db.prepare('SELECT COUNT(*) n FROM books WHERE owner_email=?').get(u).n,
 borrowed:db.prepare("SELECT COUNT(*) n FROM requests WHERE borrower_email=? AND status='Approved'").get(u).n,
 lent:db.prepare("SELECT COUNT(*) n FROM requests WHERE lender_email=? AND status='Approved'").get(u).n,
 pending:db.prepare("SELECT COUNT(*) n FROM requests WHERE lender_email=? AND status='Pending'").get(u).n});
});
app.get('/api/departments',(_req,res)=>res.json(db.prepare('SELECT DISTINCT department FROM books ORDER BY department').all().map(x=>x.department)));
app.get('/api/insights',(req,res)=>{
 const mostRequested=db.prepare(`SELECT book_title AS title, COUNT(*) AS requests FROM requests
   GROUP BY book_title ORDER BY requests DESC, title ASC LIMIT 3`).all();
 const completed=db.prepare("SELECT COUNT(*) AS n FROM requests WHERE status='Returned'").get().n;
 const active=db.prepare("SELECT COUNT(*) AS n FROM requests WHERE status IN ('Pending','Approved')").get().n;
 const available=db.prepare("SELECT COUNT(*) AS n FROM books WHERE status='Available'").get().n;
 res.json({mostRequested,completed,active,available});
});
app.use((err,req,res,_next)=>{log('error','http.unhandled_error',{method:req.method,path:req.path,message:err.message});res.status(500).json({error:'Unexpected server error.'});});
export default app;
export { db };
// Background overdue processor: persisted state is updated even when no user opens the dashboard.
function markOverdueRequests() {
  const timestamp = now();
  const overdue = db.prepare("SELECT id,book_title,borrower,borrower_email,lender,lender_email,book_id FROM requests WHERE status='Approved' AND due_date IS NOT NULL AND due_date <= ?").all(timestamp);
  if (!overdue.length) return 0;
  const update = db.prepare("UPDATE requests SET status='Overdue' WHERE id=? AND status='Approved'");
  const insert = db.prepare('INSERT INTO notifications (id,user,user_email,message,type,created_at,read) VALUES (?,?,?,?,?,?,0)');
  db.exec('BEGIN IMMEDIATE');
  try {
    for (const r of overdue) {
      update.run(r.id);
      insert.run(id(),r.borrower,r.borrower_email,`“${r.book_title}” is overdue. Please arrange its return.`,'warning',timestamp);
      insert.run(id(),r.lender,r.lender_email,`“${r.book_title}” borrowed by ${r.borrower} is overdue.`,'warning',timestamp);
    }
    db.exec('COMMIT');
  } catch (error) { db.exec('ROLLBACK'); log('error','overdue_job_failed',{message:error.message}); return 0; }
  log('info','overdue_requests_marked',{count:overdue.length});
  return overdue.length;
}
if (process.env.NODE_ENV !== 'test') {
  markOverdueRequests();
  const overdueTimer = setInterval(markOverdueRequests, 60 * 60 * 1000);
  overdueTimer.unref();
  const PORT=process.env.PORT||5000;
  app.listen(PORT,()=>log('info','server.started',{port:Number(PORT),storage:'SQLite'}));
}
