# PageVault — OpenShelf Campus Book Exchange

Full-stack campus textbook exchange application.

## Stack
- React 18 + Vite
- Node.js 22.5+ (Node.js 26 recommended) + Express
- SQLite using Node's built-in `node:sqlite` module (no native SQLite npm addon)
- JWT sessions and scrypt password hashing
- Zod server-side validation

## Run on Windows PowerShell
Open the extracted `pageshelf-project` folder (the folder containing this README and root `package.json`), then run:

```powershell
npm install
npm run install:all
npm run dev
```

Open http://localhost:5173. The API runs at http://localhost:5000.

Node.js 26 is supported. This project does not require Node.js 22 specifically. Node.js 22.5 or newer is required for the built-in SQLite module.

## First use
1. Select **Create an account**.
2. Register with your name, email address and a password of at least 8 characters.
3. Sign in and list a textbook, request a book, or manage exchanges.

The included sample books remain visible to signed-in users. To test a sample listing as its owner, create an account using the exact owner email shown in the original sample data only if you control that email; otherwise use your own account and add a test listing.

## Features
- Search books by title, author, course code, department and owner
- Filter by availability and department
- Create and manage book listings
- Borrow request, lender approval/decline, and return workflow
- 14-day return deadline after approval
- Dashboard statistics and due-date countdowns
- Automatic hourly overdue-state processing with borrower and lender notifications
- Paginated book catalogue API (bounded page size, total counts)
- Structured JSON server logs
- In-app notifications
- SQLite persistence with automatic one-time import of existing `server/data/db.json`
- Password hashing, signed JWT authentication, authorization checks and server-side validation
- Automated API tests

## Environment variables

Production startup fails safely if `JWT_SECRET` is not configured. Generate a secret with `node -e "console.log(require('node:crypto').randomBytes(48).toString('base64url'))"` and set it in your deployment environment.
Set these before deployment:
- `JWT_SECRET`: a long, random secret. Required in production; local development generates a temporary random key each server start (sign in again after a restart).
- `PORT`: API port (default 5000)
- `CLIENT_ORIGIN`: allowed browser origin (default permissive for local development)
- `DB_PATH`: optional SQLite database path

Never deploy with the development JWT secret or permissive CORS configuration. Use HTTPS in production.

## Test
From `server`:

```powershell
npm test
```

## Project structure
```
pageshelf-project/
  package.json
  README.md
  client/
    index.html
    package.json
    src/main.jsx
    src/style.css
  server/
    index.js
    package.json
    data/
      db.json          # legacy import source, retained as backup
      pagevault.sqlite # created automatically on first start
```
